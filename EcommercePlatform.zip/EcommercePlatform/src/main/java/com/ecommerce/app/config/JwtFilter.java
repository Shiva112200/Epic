package com.ecommerce.app.config;
 
import jakarta.servlet.*;
import jakarta.servlet.http.*;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
 
import java.io.IOException;
 
@Component
public class JwtFilter implements Filter {
 
	@Autowired
	private JwtUtil jwtUtil;
 
	public static String currentRole = "";
 
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
 
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
 
		String path = req.getRequestURI();
 
		// ✅ ✅ FIX 1: Allow OPTIONS (CORS preflight)
		if (req.getMethod().equalsIgnoreCase("OPTIONS")) {
			res.setStatus(HttpServletResponse.SC_OK);
			chain.doFilter(request, response);
			return;
		}
 
		// ✅ Public URLs (no token required)
		if (path.contains("/users/login") || path.contains("/users/register") || path.contains("/swagger-ui")
				|| path.contains("/v3/api-docs") || path.contains("/success.html") || path.contains("/cancel.html")|| path.contains("/api/payment/verify")) {
 
			chain.doFilter(request, response);
			return;
		}
 
		String header = req.getHeader("Authorization");
 
		// ✅ No token
		if (header == null || !header.startsWith("Bearer ")) {
			res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			res.getWriter().write("Token required");
			return;
		}
 
		String token = header.substring(7);
 
		try {
			if (!jwtUtil.validateToken(token)) {
				res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				res.getWriter().write("Token Invalid or Expired");
				return;
			}
 
			// ✅ Extract role safely
			currentRole = jwtUtil.getRole(token);
 
		} catch (Exception e) {
			res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			res.getWriter().write("Invalid Token");
			return;
		}
 
		chain.doFilter(request, response);
	}
}
 