package com.ecommerce.app.service;

import com.ecommerce.app.config.JwtFilter;
import com.ecommerce.app.entity.Cart;
import com.ecommerce.app.entity.Product;
import com.ecommerce.app.entity.User;
import com.ecommerce.app.repository.CartRepository;
import com.ecommerce.app.repository.ProductRepository;
import com.ecommerce.app.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository repo;

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private UserRepository userRepo;

    
    
    // ADD TO CART
    public Cart addToCart(Cart cart) {

        Product product = productRepo.findById(cart.getProduct().getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepo.findById(cart.getUser().getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        cart.setProduct(product);
        cart.setUser(user);

        return repo.save(cart);
    }

    
    
    // GET CART BY  userid
    public List<Cart> getCartDetails(Long userId) {
        return repo.findByUser_UserId(userId);
    }

    
    
    // GET ALL CART 
    public List<Cart> getAllCartItems() {

     if (!JwtFilter.currentRole.equals("ADMIN")){
        throw new RuntimeException("Only ADMIN can view all carts");
     }

        return repo.findAll();
    }

    
    
    // UPDATE CART by cartid
    public Cart updateCart(Long cartId, Cart cart) {

        Cart existingCart = repo.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart item not found"));

        Product product = productRepo.findById(cart.getProduct().getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        User user = userRepo.findById(cart.getUser().getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        existingCart.setQuantity(cart.getQuantity());
        existingCart.setProduct(product);
        existingCart.setUser(user);

        return repo.save(existingCart);
    }

    
    // DELETE SINGLE
    public void removeFromCart(Long cartId) {
        repo.deleteById(cartId);
    }

    
}