package com.ecommerce.app.service;

import com.ecommerce.app.entity.*;
import com.ecommerce.app.repository.*;
import com.stripe.exception.StripeException;
import com.stripe.model.checkout.Session;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepo;

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private ProductRepository productRepo;

    public double getOrderAmount(Long orderId) {

        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        if ("PAID".equals(order.getStatus())) {
            throw new RuntimeException("Order already paid");
        }

        return order.getTotalAmount();
    }

    @Transactional
    public Payment verifyAndProcessPayment(
            Long orderId,
            String sessionId
    ) throws StripeException {

        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));

        if (paymentRepo.findByOrder_OrderId(orderId).isPresent()) {
            throw new RuntimeException("Payment already completed");
        }

        Session session = Session.retrieve(sessionId);

        if (!"paid".equals(session.getPaymentStatus())) {
            throw new RuntimeException("Payment not completed");
        }

        // Reduce stock
        for (OrderItem item : order.getItems()) {

            Product product = item.getProduct();

            if (product.getStockQuantity() < item.getQuantity()) {

                throw new RuntimeException(
                        "Insufficient stock for product: "
                                + product.getName()
                );
            }

            product.setStockQuantity(
                    product.getStockQuantity() - item.getQuantity()
            );

            productRepo.save(product);
        }

        // Create payment
        Payment payment = new Payment();

        payment.setOrder(order);
        payment.setAmount(order.getTotalAmount());
        payment.setPaymentStatus("SUCCESS");
        payment.setPaymentMethod("CARD");
        payment.setCurrency("USD");
        payment.setTransactionId(session.getPaymentIntent());
        payment.setSessionId(session.getId());
        payment.setRefunded(false);
        payment.setPaymentDate(LocalDateTime.now());

        // Update order
        order.setStatus("PAID");

        orderRepo.save(order);

        return paymentRepo.save(payment);
    }

    // Get payment by id
    public Payment getPaymentById(Long paymentId) {

        return paymentRepo.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
    }

    // Get all payments
    public List<Payment> getAllPayments() {
        return paymentRepo.findAll();
    }

    // Get payment by order
    public Payment getPaymentByOrder(Long orderId) {

        return paymentRepo.findByOrder_OrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
    }

    // Refund payment
    @Transactional
    public Payment refundPayment(Long paymentId) {

        Payment payment = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));

        payment.setPaymentStatus("REFUNDED");
        payment.setRefunded(true);

        Order order = payment.getOrder();

        order.setStatus("REFUNDED");

        // Restore stock
        for (OrderItem item : order.getItems()) {

            Product product = item.getProduct();

            product.setStockQuantity(
                    product.getStockQuantity() + item.getQuantity()
            );

            productRepo.save(product);
        }

        orderRepo.save(order);

        return paymentRepo.save(payment);
    }
}