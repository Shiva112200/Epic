const BASE = "http://localhost:8085";

const token = localStorage.getItem("token");
const userId = localStorage.getItem("userId");

async function loadOrders() {
  const res = await fetch(`${BASE}/orders/user/${userId}`, {
    headers: {
      Authorization: "Bearer " + token,
    },
  });

  const orders = await res.json();

  const container = document.getElementById("ordersContainer");

  container.innerHTML = "";

  orders.forEach((order) => {
    container.innerHTML += `
        <div class="order-card"
             onclick="viewOrder(${order.orderId})">

            <h3>Order #${order.orderId}</h3>

            <p>Date: ${order.orderDate}</p>

            <p>Status: ${order.status}</p>

            <p>Total: ₹${order.totalAmount}</p>

        </div>
        `;
  });
}

function viewOrder(id) {
  window.location.href = `order-summary.html?orderId=${id}`;
}

window.onload = loadOrders;
