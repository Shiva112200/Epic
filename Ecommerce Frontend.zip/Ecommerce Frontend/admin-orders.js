const BASE = "http://localhost:8085";

const token = localStorage.getItem("token");

async function loadOrders() {
  const res = await fetch(`${BASE}/orders`, {
    headers: {
      Authorization: "Bearer " + token,
    },
  });

  const orders = await res.json();

  const table = document.getElementById("ordersTable");
  table.innerHTML = "";

  orders.forEach((order) => {
    table.innerHTML += `
        <tr>
            <td>#${order.orderId}</td>
            <td>${order.user?.username || "N/A"}</td>
            <td>${order.orderDate}</td>

            <td>
                <span class="status ${order.status}">
                    ${order.status}
                </span>
            </td>

            <td>₹${order.totalAmount}</td>

            <td>
                <button class="btn view-btn"
                    onclick="viewOrder(${order.orderId})">
                    View
                </button>

                <button class="btn ship-btn"
                    onclick="updateStatus(${order.orderId}, 'SHIPPED')">
                    Ship
                </button>

                <button class="btn deliver-btn"
                    onclick="updateStatus(${order.orderId}, 'DELIVERED')">
                    Deliver
                </button>
            </td>
        </tr>
        `;
  });
}

function viewOrder(id) {
  window.location.href = `order-summary.html?orderId=${id}`;
}

/* UPDATE STATUS */
function updateStatus(orderId, status) {
  fetch(`${BASE}/orders/status/${orderId}?status=${status}`, {
    method: "PUT",
    headers: {
      Authorization: "Bearer " + token,
    },
  }).then(() => loadOrders());
}

function logout() {
  localStorage.clear();
  window.location.href = "Login.html";
}

window.onload = loadOrders;
