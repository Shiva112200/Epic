function loadHome() {
  window.location.href = "products.html";
}

function loadCart() {
  window.location.href = "cart.html";
}

function loadOrders() {
  window.location.href = "orders.html";
}

function loadProfile() {
  window.location.href = "profile.html";
}

function scrollTopPage() {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
}

function logout() {
  Swal.fire({
    title: "Logout?",
    text: "Do you want to logout?",
    icon: "question",
    showCancelButton: true,
    confirmButtonText: "Logout",
    cancelButtonText: "Cancel",
  }).then((result) => {
    if (result.isConfirmed) {
      localStorage.removeItem("token");
      localStorage.removeItem("userId");

      Swal.fire({
        icon: "success",
        title: "Logged Out",
        timer: 1500,
        showConfirmButton: false,
      }).then(() => {
        window.location.href = "login.html";
      });
    }
  });
}

window.addEventListener("load", () => {
  const cards = document.querySelectorAll(".card");

  cards.forEach((card, index) => {
    card.style.opacity = "0";
    card.style.transform = "translateY(50px)";

    setTimeout(() => {
      card.style.transition = ".7s";
      card.style.opacity = "1";
      card.style.transform = "translateY(0)";
    }, index * 200);
  });
});
