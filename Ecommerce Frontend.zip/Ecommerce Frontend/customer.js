function loadHome() {
    window.location.href = "products.html";
}

function loadCart() {
    window.location.href = "cart.html";
}

function loadOrders() {
    window.location.href = "orders.html";
}

function loadProfile() {
    window.location.href = "profile.html";
}

function logout() {
    alert("Logged out!");
    window.location.href = "login.html";
}