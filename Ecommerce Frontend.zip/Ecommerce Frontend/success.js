const BASE = "http://localhost:8085";

const token = localStorage.getItem("token");

const params = new URLSearchParams(window.location.search);

const sessionId = params.get("session_id");
const orderId = params.get("orderId");

async function verifyPayment() {
  try {
    const response = await fetch(
      `${BASE}/api/payment/verify/${orderId}/${sessionId}`,
      {
        headers: {
          Authorization: "Bearer " + token,
        },
      },
    );

    if (!response.ok) {
      throw new Error("Payment verification failed");
    }

    const data = await response.json();

    console.log(data);

    // Success message
    document.querySelector(".verify-text").innerHTML =
      "✅ Payment Verified Successfully";

    // Redirect after 2 seconds
    setTimeout(() => {
      window.location.href = `order-summary.html?orderId=${orderId}`;
    }, 2000);
  } catch (error) {
    console.error(error);

    document.querySelector(".verify-text").innerHTML =
      "❌ Payment Verification Failed";
  }
}

verifyPayment();
