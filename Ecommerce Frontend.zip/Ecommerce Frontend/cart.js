const BASE = "http://localhost:8085";

const userId = localStorage.getItem("userId");
const token = localStorage.getItem("token");

/* ===========================
   LOADER
=========================== */

function showLoader() {
    document.getElementById("loader").style.display = "block";
}

function hideLoader() {
    document.getElementById("loader").style.display = "none";
}

/* ===========================
   LOAD CART
=========================== */

async function loadCart() {

    try {

        showLoader();

        const response = await fetch(`${BASE}/cart/${userId}`, {
            headers: {
                Authorization: "Bearer " + token
            }
        });

        const data = await response.json();

        const container = document.getElementById("cartContainer");

        container.innerHTML = "";

        let total = 0;
        let totalItems = 0;

        /* EMPTY CART */

        if (!data || data.length === 0) {

            container.innerHTML = `
                <div class="empty-cart">

                    <i class="fa-solid fa-cart-shopping"></i>

                    <h2>Your Cart is Empty</h2>

                    <p>
                        Looks like you haven't added anything yet.
                    </p>

                    <button class="shop-btn"
                    onclick="window.location.href='customer.html'">
                        Continue Shopping
                    </button>

                </div>
            `;

            document.getElementById("total").innerText = 0;
            document.getElementById("productsCount").innerText = 0;
            document.getElementById("itemCount").innerText = "0 Items";

            hideLoader();
            return;
        }

        data.forEach(item => {

            total += item.product.price * item.quantity;
            totalItems += item.quantity;

            container.innerHTML += `

            <div class="item">

                <div class="left">

                    <img
                        src="${item.product.imageUrl}"
                        alt="${item.product.name}"
                    >

                    <div class="product-info">

                        <div class="product-name">
                            ${item.product.name}
                        </div>

                        <div class="product-category">
                            Premium Product
                        </div>

                        <div class="product-price">
                            ₹${item.product.price}
                        </div>

                        <div class="product-stock">
                            <i class="fa-solid fa-circle-check"></i>
                            In Stock
                        </div>

                    </div>

                </div>

                <div class="qty-box">

                    <button
                        class="qty-btn"
                        onclick="changeQty(
                            ${item.cartId},
                            ${item.quantity},
                            -1,
                            ${item.product.productId}
                        )"
                    >
                        -
                    </button>

                    <span class="qty">
                        ${item.quantity}
                    </span>

                    <button
                        class="qty-btn"
                        onclick="changeQty(
                            ${item.cartId},
                            ${item.quantity},
                            1,
                            ${item.product.productId}
                        )"
                    >
                        +
                    </button>

                </div>

                <button
                    class="remove"
                    onclick="removeItem(${item.cartId})"
                >
                    <i class="fa-solid fa-trash"></i>
                    Remove
                </button>

            </div>

            `;
        });

        document.getElementById("total").innerText =
            total.toLocaleString("en-IN");

        document.getElementById("productsCount").innerText =
            totalItems;

        document.getElementById("itemCount").innerText =
            totalItems + " Items";

    } catch (error) {

        console.error(error);

        alert("Failed to load cart.");

    } finally {

        hideLoader();

    }
}

/* ===========================
   CHANGE QUANTITY
=========================== */

async function changeQty(
    cartId,
    currentQty,
    change,
    productId
) {

    const newQty = currentQty + change;

    if (newQty < 1) {
        return;
    }

    try {

        showLoader();

        await fetch(`${BASE}/cart/${cartId}`, {

            method: "PUT",

            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer " + token
            },

            body: JSON.stringify({

                quantity: newQty,

                user: {
                    userId: userId
                },

                product: {
                    productId: productId
                }

            })

        });

        await loadCart();

    } catch (error) {

        console.error(error);

        alert("Unable to update quantity.");

    } finally {

        hideLoader();

    }
}

/* ===========================
   REMOVE ITEM
=========================== */

async function removeItem(cartId) {

    const confirmDelete =
        confirm("Remove this item from cart?");

    if (!confirmDelete) {
        return;
    }

    try {

        showLoader();

        await fetch(`${BASE}/cart/${cartId}`, {

            method: "DELETE",

            headers: {
                Authorization: "Bearer " + token
            }

        });

        await loadCart();

    } catch (error) {

        console.error(error);

        alert("Unable to remove item.");

    } finally {

        hideLoader();

    }
}

/* ===========================
   CHECKOUT
=========================== */

async function checkout() {

    try {

        showLoader();

        const response =
            await fetch(`${BASE}/orders/${userId}`, {

                method: "POST",

                headers: {
                    Authorization: "Bearer " + token
                }

            });

        const order = await response.json();

        alert("Order Created Successfully 🎉");

        window.location.href =
            `order-summary.html?orderId=${order.orderId}`;

    } catch (error) {

        console.error(error);

        alert("Unable to create order.");

    } finally {

        hideLoader();

    }
}

/* ===========================
   LOGOUT
=========================== */

function logout() {

    const confirmLogout =
        confirm("Are you sure you want to logout?");

    if (!confirmLogout) {
        return;
    }

    localStorage.clear();

    window.location.href = "Login.html";
}

/* ===========================
   PAGE LOAD
=========================== */

window.onload = () => {

    if (!token) {

        alert("Please login first.");

        window.location.href = "Login.html";

        return;
    }

    loadCart();

};