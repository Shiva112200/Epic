const BASE = "http://localhost:8085";
const userId = localStorage.getItem("userId");
const token = localStorage.getItem("token");

/* ✅ LOAD CART */
async function loadCart() {
  const res = await fetch(`${BASE}/cart/${userId}`, {
    headers: { Authorization: "Bearer " + token },
  });

  const data = await res.json();

  const container = document.getElementById("cartContainer");
  container.innerHTML = "";

  let total = 0;

  if (data.length === 0) {
    container.innerHTML = "<p>Your cart is empty 🛒</p>";
    document.getElementById("total").innerText = 0;
    return;
  }

  data.forEach((item) => {
    total += item.product.price * item.quantity;

    container.innerHTML += `
        <div class="item">

            <div class="left">
                <img src="${item.product.imageUrl}">
                <div>
                    <b>${item.product.name}</b><br>
                    ₹${item.product.price}
                </div>
            </div>

            <!-- ✅ QUANTITY CONTROLS -->
            <div style="display:flex; align-items:center; gap:5px;">
                
                <button onclick="changeQty(${item.cartId}, ${item.quantity}, -1, ${item.product.productId})">-</button>
                
                <span>${item.quantity}</span>
                
                <button onclick="changeQty(${item.cartId}, ${item.quantity}, 1, ${item.product.productId})">+</button>

            </div>

            <!-- REMOVE -->
            <button class="remove" onclick="removeItem(${item.cartId})">
                Remove
            </button>

        </div>`;
  });

  document.getElementById("total").innerText = total;
}

/* ✅ CHANGE QUANTITY (+ / -) */
function changeQty(cartId, currentQty, change, productId) {
  const newQty = currentQty + change;

  if (newQty < 1) return; // ✅ prevent 0 or negative

  fetch(`${BASE}/cart/${cartId}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token,
    },
    body: JSON.stringify({
      quantity: newQty,
      user: { userId: userId },
      product: { productId: productId },
    }),
  }).then(() => loadCart());
}

/* ✅ REMOVE ITEM */
function removeItem(cartId) {
  fetch(`${BASE}/cart/${cartId}`, {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token },
  }).then(() => loadCart());
}

/* ✅ CHECKOUT */
/* ✅ CHECKOUT */
function checkout() {
  fetch(`${BASE}/orders/${userId}`, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + token,
    },
  })
    .then((res) => res.json())
    .then((order) => {
      alert("Order Created Successfully");

      window.location.href = `order-summary.html?orderId=${order.orderId}`;
    })
    .catch((err) => {
      console.error(err);
      alert("Unable to create order");
    });
}

/* ✅ INIT */
window.onload = loadCart;

function logout() {
  // Clear all stored login data
  localStorage.clear();

  // Redirect to login page
  window.location.href = "Login.html";
}
