const BASE = "http://localhost:8085";

const token = localStorage.getItem("token");

const params = new URLSearchParams(window.location.search);
const orderId = params.get("orderId");

async function loadOrder() {
  const res = await fetch(`${BASE}/orders/${orderId}`, {
    headers: {
      Authorization: "Bearer " + token,
    },
  });

  const order = await res.json();
  const payBtn = document.querySelector(".pay-btn");

  if (order.status === "PAID") {
    payBtn.style.display = "none";
  }

  // HEADER
  document.getElementById("orderTitle").innerText = "Order #" + order.orderId;

  document.getElementById("orderDate").innerText = "Date: " + order.orderDate;

  document.getElementById("status").innerText = order.status;

  document.getElementById("status").classList.add(order.status);

  // ITEMS
  const container = document.getElementById("itemsContainer");

  container.innerHTML = "";

  order.items.forEach((item) => {
    container.innerHTML += `
        <div class="item">

            <img src="${item.productImageUrl}">

            <div class="details">
                <h4>${item.productName}</h4>
                <p>${item.productDescription}</p>
                <p>Qty: ${item.quantity}</p>
                <p>Price: ₹${item.price}</p>
                <p><b>Total: ₹${item.price * item.quantity}</b></p>
            </div>

        </div>
        `;
  });

  // TOTALS
  document.getElementById("itemsTotal").innerText = "₹" + order.totalAmount;

  document.getElementById("grandTotal").innerText = "₹" + order.totalAmount;
}

window.onload = loadOrder;

function logout() {
  localStorage.clear();
  window.location.href = "Login.html";
}
document.getElementById("payBtn").addEventListener("click", async () => {
  try {
    const response = await fetch(
      `${BASE}/api/payment/create-checkout-session/${orderId}`,
      {
        method: "POST",
        headers: {
          Authorization: "Bearer " + token,
        },
      },
    );

    const data = await response.json();

    // Stripe checkout page par redirect
    window.location.href = data.url;
  } catch (error) {
    console.error(error);
    alert("Unable to start payment");
  }
});
